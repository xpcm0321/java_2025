package com.company.java015_ex;

class User004 {
	final String division = "123456-1234567";
	final String jumin = "A";
}

public class SelfTest004 {
	public static void main(String[] args) {
		User004 c1 = new User004('B', "200101-1234567");
		System.out.println(c1);
		User004 c2 = new User004();
		System.out.println(c2);
	}
}
/*
코드 수정
*/