package com.company.java015_ex;

class Sawon005 {
	int pay = 10000;
	
	static int su = 10;
	// static int basicpay = pay;
	static int basicpay2;
	static { basicpay2 = 20000; }
	
	public static void showSu() {System.out.println(su);}
	// public static void showPay() {System.out.println(this.pay);}
	
	public void showAll001() {
		System.out.println(su);
		System.out.println(this.pay);
	}
	public static void showAll002() {
		// showAll001(); // static X
		// System.out.println(this.pay);
	}
}

public class SelfTest003 {
	public static void main(String[] args) {
		Sawon005 sola = new Sawon005();
		sola.showAll001();
	}
}
/*
클래스 작성하고 에러가 난다면 에러나는 이유 적기
*/