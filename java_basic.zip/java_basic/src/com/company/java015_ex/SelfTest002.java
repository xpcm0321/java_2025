package com.company.java015_ex;

class A {
	int a;
	static String company;
	void method() {int a;}
}

public class SelfTest002 {
	public static void main(String[] args) {
	}
}
/*
클래스 변수, 인스턴스 변수, 지역변수로 구분하고 오류날만한 코드 작성
*/