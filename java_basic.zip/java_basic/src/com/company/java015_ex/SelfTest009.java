package com.company.java015_ex;

interface Vehicle16 {public void run();}
class MotorCycle16 implements Vehicle16 {
	@Override public void run() {
		System.out.println("오토바이가 달립니다.");
	}
	public void helmet() {
		System.out.println("헬멧을 착용합니다.");
	}
}
class Car16 implements Vehicle16 {
	@Override public void run() {
		System.out.println("자동차가 달립니다.");
	}
}
class Driver16 {
	public void drive() {}
}
public class SelfTest009 {
	public static void main(String[] args) {
		Driver16 driver16 = new Driver16();
		
		MotorCycle16 MotorCycle16 = new MotorCycle16();
		Car16 Car16 = new Car16();
		
		driver16.drive(Car16);
		
		System.out.println("\n\n>> 자동차가 고장나서 교통수단을 바꿉니다!");
		driver16.drive(MotorCycle16);
	}
}
