package com.company.java015_ex;

class Coffee012 {
	private String name;
	private int price;
	private int num;
	
	public Coffee012() { super(); }
	public Coffee012(String name, int price, int num) { super(); this.name = name; this.price = price; this.num = num; }
	@Override public String toString() { return "Coffee012 [name=" + name + ", price=" + price + ", num=" + num + "]"; }
	
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	public int getPrice() { return price; }
	public void setPrice(int price) { this.price = price; }
	public int getNum() { return num; }
	public void setNum(int num) { this.num = num; }
	
	public void show() {
		System.out.println("=====커피");
		System.out.println("커피명 : " + this.name);
		System.out.println("커피잔수 :" + this.num);
		System.out.println("커피가격 : " + this.price*this.num);
	}
}

public class SelfTest001 {
	public static void main(String[] args) {
		Coffee012 a1 = new Coffee012("까페라떼" , 2, 4000);
		a1.show();
		Coffee012 a2 = new Coffee012();
		a2.show();
	}
}
/*
클래스명 : Coffee012
커피 이름과 가격 출력
*/