package com.company.java015_ex;

public class SelfTest008 {
	public static void main(String[] args) {
	}
}
/*
abstract 과 interface 의 공통점과 차이점
*/