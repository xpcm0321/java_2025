package com.company.java001;

public class A004 {
	public static void main(String[] args) {
		System.out.println("1. 파일명저장 : A004.java ");
		System.out.println("2. 클래스 몇 개 : 5개");
		System.out.println("3. 클래스 이름 : A004.class / A41.class / A42.class / A43.class / A43$A44.class");
	}

}
// D:\java_2025\java_basic\bin\com\company\java001
class A41{}
class A42{}
class A43{
	class A44{}
}
