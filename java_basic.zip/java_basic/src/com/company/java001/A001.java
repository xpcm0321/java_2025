package com.company.java001;

public class A001 {
	public static void main(String [] args) {
		System.out.println("Hello");
		
	} // end main
} // end class

 // 한 줄 주석(설명글)
/* ctrl + (화면크게) / ctrl - (화면작게)
 * 
 * 3번쨰 줄 : public class A001 {
 * 		public    아무데서나 접근 가능 / class     부품객체 / A001      클래스이름
 * 4번째 줄 : jvm 구동 시작점
 * 		public static void main(String [] args){}
 * 		public 아무데서나 접근 가능 / static 메모리 상시 사용 가능 / void main(String [] args) 전원버튼 이름
 * 5번째 줄 : System.out.println("Hello");
 * 		System (운영체제) out ( cmd ) println (출력)
 * 
 * ctrl + fll (실행)
 */
