package com.company.java002_ex;

public class PrintEx001 {

	public static void main(String[] args) {
		// 1. println
		System.out.println("좋아하는 색상은 skyblue입니다.");
		
		// 2. print + \n -> println
		System.out.printf("좋아하는 색상은 skyblue입니다.\n");
		
		// 3. ★ printf %s
		System.out.printf("좋아하는 색상은 %s입니다.", "Skyblue");
	}
}
