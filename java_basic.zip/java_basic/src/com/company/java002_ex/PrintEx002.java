package com.company.java002_ex;

public class PrintEx002 {
	public static void main(String[] args) {
		System.out.println( 10 + "+" + 3 + "=" + (10 + 3));
		// 10+3=13
	}
}