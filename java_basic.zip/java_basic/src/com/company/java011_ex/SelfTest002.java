package com.company.java011_ex;

public class SelfTest002 {
	public static void main(String[] args) {
		System.out.println(10 + "+" + 20);
	}
}
/*
[SelfTest002] 출력(2)
System.out.println(10 + 20);  결과 : 10+20 문자열이 나오게 만들기
*/