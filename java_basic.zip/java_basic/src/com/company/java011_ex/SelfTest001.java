package com.company.java011_ex;

public class SelfTest001 {
	public static void main(String[] args) {
		System.out.println("Hello");
	}
}
/*
[SelfTest001] 출력(1) 
Hello 출력
*/