package com.company.java006_ex;

public class Repeat003 {
	public static void main(String[] args) {
		for (int i = 1; i <= 3; i++) {
			System.out.print(i + "\t");
		}
	}
}
/*
for 를 이용해서 1 2 3 출력
*/