package com.company.java005_ex;

public class ForEx003 {

	public static void main(String[] args) {
		int sum = 0;
		
		for (int i = 1; i <= 10; i++) {
			sum += i;
		}
		System.out.println("1~10까지의 합 : " + sum);
	}
} // ctrl + shift + f 줄 정렬
/*
연습문제3)  
패키지명 : com.company.java005_ex
클래스명 :  ForEx003
출력내용 :   for 이용
1~10까지의 합을 구하시오.
3번문제 업그레이드 : upgrade)  시간나면 도전!
1+2+3+4+5+6+7+8+9+10=55
*/