package com.company.java008;

public class Method001 {
	// #1. 함수정의
	// public static 리턴값 메서드명( 파라미터 ){ }
	public static void hello() { System.out.println("Hello"); }
	////////////////////////////////////////
	public static void main(String[] args) {
		// #2. 함수호출  메서드명( 파라미터 )
		hello();
		hello();
		hello();
	}
	///////////////////////////////////////
	
	
}
