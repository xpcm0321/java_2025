package com.company.java011_ex;

public class SelfTest008 {

	public static void main(String[] args) {
		for (int i = 1; i < 11; i++) {
			System.out.print(i + "\t");
		}
	}
}
/*
[SelfTest008] for
  			1,2,3,4,5,6,7,8,9,10 출력
*/