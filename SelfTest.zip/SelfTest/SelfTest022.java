package com.company.java011_ex;

public class SelfTest022 {

	public static void main(String[] args) {
		System.out.println("오버로딩은 비슷한 동작을 수행하는 메서드들을 같은 이름으로 일관되는 작업하는 것");
		System.out.println("오버라이딩은 상속 시 자식클래스에서 맞게 메서드를 수정하는 것");
	}

}
/*
[SelfTest022] 함수(5) :  
			메서드오버로딩이과 오버라이딩이란?
*/