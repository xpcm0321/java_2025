package com.company.java011_ex;

public class SelfTest010 {

	public static void main(String[] args) {
		int i = 1;
		do {
			System.out.print(i + "\t");
			i++;
		} while (i < 11);
	}
}
/*
[SelfTest010] do while 
 			1,2,3,4,5,6,7,8,9,10 출력
*/